<%--
  Created by IntelliJ IDEA.
  User: felip
  Date: 02/07/2023
  Time: 12:11
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Cadastro de Livros</title>
</head>
<body>
<h1>Cadastro de Livros</h1>
<form action="register_book" method="post">
    <label for="name">Nome:</label>
    <input type="text" id="name" name="name" required><br>
    <label for="author">Autor:</label>
    <input type="text" id="author" name="author" required><br>
    <label for="status">Status:</label>
    <select id="status" name="status" required>
        <option value="DISPONIVEL">Disponível</option>
        <option value="EMPRESTADO">Emprestado</option>
        <option value="INDISPONIVEL">Indisponível</option>
    </select><br>
    <input type="submit" value="Cadastrar">
</form>
</body>
</html>

