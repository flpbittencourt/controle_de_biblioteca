<!DOCTYPE html>
<html>
<head>
    <title>Lista de Livros</title>
</head>
<body>
<h1>Lista de Livros</h1>
<table>
    <tr>
        <th>Identificador</th>
        <th>Nome</th>
        <th>Autor</th>
        <th>Data de Criação</th>
        <th>Status</th>
        <th>Ações</th>
    </tr>
</table>
</body>
</html>
