import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class BookService {
    private List<Book> books;

    public BookService() {
        books = new ArrayList<>();
        populateBookListFromDatabase();
    }

    private void populateBookListFromDatabase() {
        try {
            // Estabelecer a conexão com o banco de dados MySQL
            String url = "jdbc:mysql://localhost:3306/nome_do_banco";
            String username = "usuario";
            String password = "senha";
            Connection connection = DriverManager.getConnection(url, username, password);

            // Consulta SQL para selecionar todos os livros
            String sql = "SELECT * FROM livros";

            // Criar o PreparedStatement e executar a consulta
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            // Percorrer o resultado do ResultSet para obter os dados dos livros
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String nome = resultSet.getString("nome");
                String autor = resultSet.getString("autor");
                Date dataCriacao = resultSet.getDate("data_criacao");
                String status = resultSet.getString("status");

                // Criar um objeto Book com os dados e adicionar à lista de livros
                Book book = new Book(id, nome, autor, dataCriacao, BookStatus.valueOf(status));
                books.add(book);
            }

            // Fechar o ResultSet, PreparedStatement e a conexão com o banco de dados
            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Book> getAllBooks() {
        return books;
    }

    public void addBook(Book book) {
        books.add(book);
    }
}
