package com.example.bookmanager;

import java.io.*;

import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet("/register_book")
public class RegisterBookServlet extends HttpServlet {
    private BookService bookService; // Classe de serviço para acessar os dados dos livros

    @Override
    public void init() throws ServletException {
        // Inicialize o serviço de livros no método init da servlet
        bookService = new BookService();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtenha os parâmetros enviados pelo formulário HTML
        String name = request.getParameter("name");
        String author = request.getParameter("author");
        String status = request.getParameter("status");

        // Crie um novo objeto Book com os dados fornecidos
        Book newBook = new Book(name, author, BookStatus.valueOf(status));

        // Adicione o novo livro ao serviço de livros
        bookService.addBook(newBook);

        // Redirecione para a página de listagem de livros após o cadastro
        response.sendRedirect("list_books");
    }
}
